#' @title vangogh
#' @name vangogh
#' @details list of palettes generated from Vincent van Gogh's paintings
#' @description list of palettes generated from Vincent van Gogh's paintings
#' @keywords internal
"_PACKAGE"
NULL
